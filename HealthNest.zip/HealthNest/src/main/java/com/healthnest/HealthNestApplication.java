package com.healthnest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HealthNestApplication {

	public static void main(String[] args) {
		SpringApplication.run(HealthNestApplication.class, args);
	}

}
